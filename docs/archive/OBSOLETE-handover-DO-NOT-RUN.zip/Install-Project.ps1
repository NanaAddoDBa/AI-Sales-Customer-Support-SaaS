[CmdletBinding()]
param(
    [string]$Destination = 'C:\Users\nanaa\Desktop\Studies\Self_Studies\Codes\Projects\AI Sales & Customer Support SaaS',
    [switch]$Push
)
$ErrorActionPreference = 'Stop'
$Remote = 'https://github.com/NanaAddoDBa/AI-Sales-Customer-Support-SaaS.git'
$Bundle = Join-Path $PSScriptRoot 'implementation.bundle'
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw 'Git is required. Install Git for Windows before running this script.'
}
if (-not (Test-Path -LiteralPath $Bundle -PathType Leaf)) {
    throw 'No implementation bundle was recovered. Read STATUS.json. Nothing has been copied or pushed.'
}
if (Test-Path -LiteralPath $Destination) {
    if (-not (Test-Path -LiteralPath $Destination -PathType Container)) {
        throw "Destination is not a directory: $Destination"
    }
    if (@(Get-ChildItem -LiteralPath $Destination -Force).Count -gt 0) {
        throw "Destination is not empty. No files were overwritten: $Destination"
    }
}
$Parent = Split-Path -Parent $Destination
New-Item -ItemType Directory -Force -Path $Parent | Out-Null
& git clone -- $Bundle $Destination
if ($LASTEXITCODE -ne 0) { throw 'Cloning the implementation bundle failed.' }
& git -C $Destination remote set-url origin $Remote
if ($LASTEXITCODE -ne 0) { throw 'Setting the GitHub remote failed.' }
Write-Host "Repository and modular commit history copied to: $Destination"
& git -C $Destination log --oneline -15
if ($LASTEXITCODE -ne 0) { throw 'Could not read the copied commit history.' }

$Patch = Join-Path $PSScriptRoot 'uncommitted-tracked-changes.patch'
if (Test-Path -LiteralPath $Patch) {
    Write-Warning 'Additional uncommitted tracked changes are provided as a patch. They are not automatically applied or pushed.'
}
if ($Push) {
    # The explicit -Push switch publishes the recovered committed branch.
    # No force push; Git will reject conflicting remote history.
    & git -C $Destination push --set-upstream origin HEAD:main
    if ($LASTEXITCODE -ne 0) {
        throw 'GitHub push failed. The local copy remains intact. Use your normal Git credential manager; do not paste tokens into chat.'
    }
    Write-Host 'Committed history was pushed to the GitHub main branch.'
} else {
    Write-Host 'GitHub was not changed. Publishing requires running git push explicitly.'
}