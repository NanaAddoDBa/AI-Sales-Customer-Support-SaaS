# AI Sales & Customer Support SaaS — handover

Read STATUS.json first. It records whether an implementation repository and
its Git history were recovered. This export does not claim production readiness.

When implementation.bundle is present:
1. Extract this entire handover archive into a temporary folder.
2. Open PowerShell in that extracted folder.
3. Run: .\Install-Project.ps1
4. To explicitly copy AND publish the committed history, run instead:
   .\Install-Project.ps1 -Push

The installer uses the requested Windows destination and refuses to overwrite
a nonempty folder. Git authentication is handled by your local Git installation.
It never force-pushes.

committed-source.zip is a source snapshot. implementation.bundle preserves Git
history. Any uncommitted tracked changes are exported separately as a patch.
Untracked files are listed in STATUS.json and are not silently committed.

No live deployment or production acceptance checks were performed by this
handover exporter. Consult the implementation's README and readiness documents
for build instructions and outstanding work.
